
export const firebaseConfig = {
  fire: {
  apiKey: 'AIzaSyD7gnr0b0PzJ3JSrLj0Fip1sdd2Kk2A_Zc',
  authDomain: 'ionic-33d1c.firebaseapp.com',
  databaseURL: 'https://ionic-33d1c.firebaseio.com',
  projectId: 'ionic-33d1c',
  storageBucket: 'ionic-33d1c.appspot.com',
  messagingSenderId: '663787614666'
  }
};
